package com.jarvis.ai

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.*
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.*

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }
    private var listening by mutableStateOf(false)
    private var spoken by mutableStateOf("")
    private var answer by mutableStateOf("Hey Boss! Main Jarvis hoon. Aapki command ka intezar hai.")
    private var apiKey by mutableStateOf("")
    private var page by mutableStateOf("Home")
    private var permissionStatus by mutableStateOf("Permissions: user approval required")
    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) listen() else say("Microphone permission allow karein.") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        apiKey = prefs.getString("api_key", "") ?: ""
        tts = TextToSpeech(this, this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF29B6FF), secondary = Color(0xFFB14CFF), background = Color(0xFF060B18), surface = Color(0xFF10182A))) {
                JarvisUI(page, { page = it }, apiKey, { apiKey = it }, { prefs.edit().putString("api_key", it.trim()).apply(); answer = "API key saved on this device." }, spoken, answer, listening, permissionStatus, { startListening() }, { handleCommand(it) }, { askGemini(it) }, { say(it) }, { openAccessibility() }, { requestMic() })
            }
        }
    }
    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) { tts.language = Locale("en", "IN"); tts.setSpeechRate(0.94f) } }
    private fun say(text: String) { answer = text; if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply") }
    private fun requestMic() { if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) listen() else micPermission.launch(Manifest.permission.RECORD_AUDIO) }
    private fun startListening() { if (!SpeechRecognizer.isRecognitionAvailable(this)) { say("Is device par speech recognition available nahi hai."); return }; requestMic() }
    private fun listen() {
        recognizer?.destroy(); recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN"); putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true); putExtra(RecognizerIntent.EXTRA_PROMPT, "Hey Jarvis, boliye") }
        listening = true
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { listening = true }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { listening = false }
            override fun onError(error: Int) { listening = false }
            override fun onResults(results: Bundle?) { listening = false; val s = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty(); spoken = s; if (s.isNotBlank()) handleCommand(s) }
            override fun onPartialResults(partialResults: Bundle?) { spoken = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty() }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        }); recognizer?.startListening(intent)
    }
    private fun handleCommand(raw: String) {
        val s = raw.lowercase(Locale.getDefault())
        when {
            s.contains("time") || s.contains("samay") -> say("Abhi ${java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())} ho rahe hain.")
            s.contains("open youtube") || s.contains("youtube kholo") -> openApp("com.google.android.youtube", "YouTube")
            s.contains("open chrome") || s.contains("chrome kholo") -> openApp("com.android.chrome", "Chrome")
            s.contains("open settings") || s.contains("settings kholo") -> startActivity(Intent(Settings.ACTION_SETTINGS))
            s.contains("wifi") && (s.contains("setting") || s.contains("open")) -> startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            s.contains("bluetooth") -> startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            s.contains("alarm") -> { val i = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_MESSAGE, "Jarvis Alarm"); if (i.resolveActivity(packageManager) != null) startActivity(i) else say("Alarm app nahi mili.") }
            s.contains("calendar") || s.contains("schedule") || s.contains("event") -> startActivity(Intent(Intent.ACTION_INSERT).setData(Uri.parse("content://com.android.calendar/events")))
            s.contains("lock phone") || s.contains("screen lock") -> { say("Phone lock karne ke liye Jarvis Device Control accessibility permission enable karein."); openAccessibility() }
            s.contains("screenshot") -> say("Screenshot action ke liye accessibility permission aur Android version ke mutabik implementation chahiye. Abhi supported nahi hai.")
            s.contains("reminder") -> say("Reminder ke liye: ${raw}. Main abhi aapko reminder app kholne mein madad kar sakti hoon.").also { startActivity(Intent(AlarmClock.ACTION_SET_ALARM)) }
            s.contains("call ") -> { val n = raw.substringAfter("call ").trim(); startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(n)))) }
            s.contains("message ") || s.contains("sms ") -> { val n = raw.substringAfter("message ").substringAfter("sms ").trim(); startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(n)))) }
            s.contains("hey jarvis") -> say("Yes Boss. Boliye, kya karna hai?")
            else -> askGemini(raw)
        }
    }
    private fun openApp(pkg: String, label: String) { val i = packageManager.getLaunchIntentForPackage(pkg); if (i != null) startActivity(i) else say("$label install nahi hai.") }
    private fun openAccessibility() { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
    private fun askGemini(prompt: String) {
        val key = apiKey.trim(); if (key.isEmpty()) { say("Settings mein Gemini API key save karein."); return }
        answer = "Jarvis soch rahi hai…"
        scope.launch(Dispatchers.IO) {
            try {
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$key")
                val conn = (url.openConnection() as HttpURLConnection).apply { requestMethod = "POST"; connectTimeout = 20000; readTimeout = 30000; doOutput = true; setRequestProperty("Content-Type", "application/json") }
                val body = JSONObject().put("system_instruction", JSONObject().put("parts", org.json.JSONArray().put(JSONObject().put("text", "You are Jarvis, a warm, helpful female AI companion. Address the user as Boss. Do not claim to execute device actions unless done by the app. Ask before any consequential action. Respond in the user's language.")))).put("contents", org.json.JSONArray().put(JSONObject().put("parts", org.json.JSONArray().put(JSONObject().put("text", prompt)))))
                conn.outputStream.use { it.write(body.toString().toByteArray()) }
                val response = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream).bufferedReader().readText()
                val text = JSONObject(response).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text") ?: "Gemini response nahi mila. API key aur internet check karein."
                withContext(Dispatchers.Main) { say(text) }
            } catch (e: Exception) { withContext(Dispatchers.Main) { say("Network/API error: ${e.localizedMessage ?: "unknown"}") } }
        }
    }
    override fun onDestroy() { recognizer?.destroy(); if (::tts.isInitialized) tts.shutdown(); scope.cancel(); super.onDestroy() }
}

@Composable
fun JarvisUI(page: String, navigate: (String)->Unit, key: String, changeKey: (String)->Unit, saveKey: ()->Unit, spoken: String, answer: String, listening: Boolean, permissionStatus: String, listen: ()->Unit, command: (String)->Unit, ask: (String)->Unit, speak: (String)->Unit, accessibility: ()->Unit, mic: ()->Unit) {
    var input by remember { mutableStateOf("") }
    var apiDraft by remember(key) { mutableStateOf(key) }
    val items = listOf("Home", "Voice", "Tasks", "Calendar", "Memory", "Device Control", "Gaming Mode", "Permissions", "Settings", "About")
    Row(Modifier.fillMaxSize().background(Color(0xFF060B18))) {
        Column(Modifier.width(150.dp).fillMaxHeight().verticalScroll(rememberScrollState()).padding(8.dp)) {
            Text("✦ JARVIS", color=Color(0xFF36BFFF), fontSize=23.sp, fontWeight=FontWeight.Black); Text("AI COMPANION • ONLINE", color=Color.Green, fontSize=10.sp); Spacer(Modifier.height(14.dp))
            items.forEach { Text(if (page==it) "▣  $it" else "☷  $it", color=if(page==it) Color.Cyan else Color.White, modifier=Modifier.fillMaxWidth().clickable { navigate(it) }.padding(vertical=11.dp).background(if(page==it) Color(0x3327BFFF) else Color.Transparent, RoundedCornerShape(10.dp)).padding(6.dp), fontSize=12.sp) }
        }
        Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()).padding(12.dp), horizontalAlignment=Alignment.CenterHorizontally) {
            Text("JARVIS AI", color=Color(0xFF42C8FF), fontSize=26.sp, fontWeight=FontWeight.Bold); Text("Your personal AI companion", color=Color.LightGray, fontSize=12.sp)
            Spacer(Modifier.height(20.dp)); Box(Modifier.fillMaxWidth().height(190.dp).background(Brush.verticalGradient(listOf(Color(0xFF13284A), Color(0xFF151023))), RoundedCornerShape(24.dp)), contentAlignment=Alignment.Center) { Column(horizontalAlignment=Alignment.CenterHorizontally) { Text("◉", color=Color.Cyan, fontSize=70.sp); Text("3D AVATAR PLACEHOLDER", color=Color.White, fontWeight=FontWeight.Bold); Text("Avatar runtime can be integrated", color=Color.LightGray, fontSize=11.sp) } }
            Spacer(Modifier.height(14.dp)); Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF111B2E)), modifier=Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) { Text("Jarvis", color=Color.Cyan, fontWeight=FontWeight.Bold); Text(answer, color=Color.White); if(spoken.isNotBlank()) Text("You: $spoken", color=Color.LightGray, fontSize=12.sp) } }
            Spacer(Modifier.height(14.dp)); Button(onClick=listen, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF145BBD))) { Text(if(listening) "Listening…" else "🎙  Tap to Speak") }
            OutlinedTextField(value=input, onValueChange={input=it}, label={Text("Type command or ask Jarvis")}, modifier=Modifier.fillMaxWidth(), colors=OutlinedTextFieldDefaults.colors(focusedTextColor=Color.White, unfocusedTextColor=Color.White, focusedBorderColor=Color.Cyan))
            Button(onClick={ if(input.isNotBlank()) { command(input); input="" } }, modifier=Modifier.fillMaxWidth()) { Text("Run command") }
            Spacer(Modifier.height(12.dp)); when(page) {
                "Settings" -> { Text("Gemini API Configuration", color=Color.Cyan); OutlinedTextField(apiDraft, { apiDraft=it }, label={Text("Gemini API key")}, modifier=Modifier.fillMaxWidth()); Button(onClick={changeKey(apiDraft);saveKey()}) { Text("Save API Key") }; Text("API key stored locally in app preferences. Do not share it.", color=Color.LightGray, fontSize=11.sp) }
                "Permissions" -> { Text(permissionStatus, color=Color.White); Button(onClick=mic) { Text("Grant Microphone") }; Button(onClick=accessibility) { Text("Open Accessibility settings") }; Text("Enable only permissions you understand. SMS/call/device actions require explicit Android permission and confirmation.", color=Color.LightGray, fontSize=12.sp) }
                "Device Control" -> { Button(onClick=accessibility) { Text("Set up Accessibility control") }; Button(onClick={command("open settings")}) { Text("Open Android Settings") }; Button(onClick={command("bluetooth")}) { Text("Bluetooth devices") }; Button(onClick={command("wifi settings")}) { Text("Wi-Fi settings") } }
                "Calendar" -> { Button(onClick={command("calendar")}) { Text("Create calendar event") }; Button(onClick={command("alarm")}) { Text("Set alarm") } }
                "Tasks" -> { Text("Tasks execute only after your command. Use voice or command input above.", color=Color.White) }
                "Memory" -> { Text("Local memory (30 MB target)", color=Color.Cyan); Text("Conversation persistence and memory controls are a starter implementation; do not store sensitive data without consent.", color=Color.White) }
                "Voice" -> { Button(onClick=listen) { Text("Start voice recognition") }; Text("Female-style voice depends on the Android installed TTS voice. Change voice in system Text-to-Speech settings.", color=Color.White) }
                "Gaming Mode" -> Text("Gaming Mode: quick launch and low-distraction interface (planned extension).", color=Color.White)
                "About" -> Text("Jarvis AI Android assistant. Device commands require Android permissions. Gemini cloud responses require your own API key and internet.", color=Color.White)
                else -> { Text("QUICK ACTIONS", color=Color.Cyan, fontWeight=FontWeight.Bold); listOf("Open YouTube", "Open Chrome", "Set alarm", "Calendar", "Bluetooth", "Time").forEach { OutlinedButton(onClick={command(it.lowercase())}, modifier=Modifier.fillMaxWidth()) { Text(it) } } }
            }
            Spacer(Modifier.height(18.dp)); Text("Permission-first • User-controlled • Online", color=Color(0xFF75BFFF), fontSize=11.sp)
        }
    }
}
