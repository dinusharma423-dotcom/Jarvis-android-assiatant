# Jarvis AI Android — Termux Build Project

A permission-first Android assistant project with a neon dashboard, speech-to-text, Android TTS replies, Gemini generateContent chat (bring your own API key), quick intents for installed apps/settings, alarm/calendar/dial/SMS composer handoff, and a user-enabled Accessibility service scaffold.

## Build in Termux (commands separately)

```bash
pkg update && pkg upgrade -y
pkg install openjdk-17 gradle git unzip -y
termux-setup-storage
cd ~/storage/downloads
unzip JarvisAI_FullStarter.zip
cd JarvisAI_FullStarter
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

If the first Gradle build fails due to missing Android SDK, install Android command-line tools/SDK in Termux and configure `ANDROID_HOME`; Gradle plugin downloads also need internet.

## Setup
1. Install the debug APK and launch Jarvis.
2. Open Settings, paste your Gemini API key, and save. Keep it private; API requests are made directly to Google from this app.
3. Tap Speak and grant microphone permission when Android asks.
4. Accessibility > Jarvis Device Control can be enabled manually in Android Settings. Do not enable it unless you understand the access it grants.

## Reality / safety notes
- This is a functioning starter foundation, not a production-ready always-on assistant. Android background microphone/wake-word service restrictions vary by OS and OEM. “Hey Jarvis” always-on wake-word is not implemented in this project.
- Gemini Live real-time bidirectional audio/WebSocket is not implemented; current Gemini integration uses `generateContent` text. Speech recognition and voice output use Android's installed speech/TTS providers. Choose an available female voice in Android Text-to-Speech settings if the device offers one.
- A rendered, rigged 3D avatar with lip-sync needs a model/runtime such as a compatible GLB plus Filament/SceneView; the dashboard currently has a visual placeholder.
- Persistent semantic long-term memory, exact 30 MB memory manager, autonomous multitasking, phone lock, screenshot capture, and actual Bluetooth audio routing are not fully implemented. The app does not claim these capabilities.
- Calls open the dialer; SMS opens a message composer. Sending messages/calling directly needs appropriate permissions, user consent, and additional contact-resolution implementation.
- Device controls must remain user-triggered. Never grant accessibility, contacts, SMS, or call permissions to an app you do not trust.
